import './bootstrap';
import 'laravel-datatables-vite';
import './scripts';

import.meta.glob([
    '../images/**',
    '../fonts/**',
]);