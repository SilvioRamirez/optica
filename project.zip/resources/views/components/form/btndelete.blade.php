<div class="flex-center position-ref full-height">
	<div class="top-right links text-center">
		{!! Form::button('<i class="fa fa-trash-alt"></i> Eliminar', ['type' => 'submit', 'class' => 'btn btn-danger btn-block'])  !!}
	</div>
</div>