<div class="form-group">
    <fieldset disabled="">
        <label class="form-label" ><strong> {{ $label }} </strong></label>
         <p class=""> {{$value}} </p>
    </fieldset>
</div>